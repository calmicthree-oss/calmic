# photovault/services/__init__.py
"""
PhotoVault Services Package
Contains service modules for business logic
"""